export default {
  template: `
    <div class="header">
      <router-link to="/"><img src="./img/ssafy_logo.png" class="ssafy_logo" /></router-link>
      <p class="logo">도서관리 사이트</p>
    </div>
  `
};